"""AMAN application package."""
